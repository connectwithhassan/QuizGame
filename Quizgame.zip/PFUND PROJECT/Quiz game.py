import tkinter
from tkinter import *
import random

questions=[
    "Q: How many keywords are there in Python?",
    "Q: Which Brackets are used in List?",
    "Q: The loop inside a loop is called?",
    "Q: Which keyword is used to define a function?",
    "Q: The language which computer understands is called?",
    "Q: Which type of Programming does Python support?",
    "Q: Is Python case sensitive?",
    "Q: Which of the following is correct python extension file?",
    "Q: Which of the following is used to give single line comment in python?",
    "Q: Which of the following is used to create an empty set in python?"
]
answers_choice = [
    ["20","37","33","30"],
    ["(-)","[-]","{-}","none of these"],
    ["Nested loop","while loop","for loop","none of these"],
    ["if","break","def","return"],
    ["Machine language","Low-level Language","Binary Language","All of these"],
    ["Object-oriented Programming","Structured Programming","Functional programming","All of these"],
    ["No","Yes","Machine dependent","None of these"],
    [".python",".py",".pl",".p"],
    ["//","#","!","/*"],
    ["(-)","[-]","{-}","set()"]
]


answer=[3,1,1,3,4,4,2,2,2,4]


user_answers=[]

indexes = []
def gen():
    global indexes
    while(len(indexes) < 10):
        x = random.randint(0,9)
        if x in indexes:
            continue
        else:
            indexes.append(x)

def showresult(score):
     lblQuestion.destroy()
     r1.destroy()
     r2.destroy()
     r3.destroy()
     r4.destroy()
     labelimage = Label(
        root,
        background = "#ffffff",
        border = 0,
     )
     labelimage.pack()
     labelresulttext = Label(
        root,
        font = ("Consolas",20),
        background = "#ffffff",
     )
     labelresulttext.pack()
     if score >= 10:
        img = PhotoImage(file="e:\university\1st SEM\PFUND PROJECT\great.png")
        labelimage.configure(image=img)
        labelimage.image = img
        labelresulttext.configure(text="You Are Excellent !!")
     elif (score >= 5 and score < 10):
        img = PhotoImage(file="e:\university\1st SEM\PFUND PROJECT\ok.png")
        labelimage.configure(image=img)
        labelimage.image = img
        labelresulttext.configure(text="You Can Be Better !!")
     else:
        img = PhotoImage(file="e:\university\1st SEM\PFUND PROJECT\bad.png")
        labelimage.configure(image=img)
        labelimage.image = img
        labelresulttext.configure(text="You Should Work Hard !!")



def calc():
    global indexes,user_answers,answer
    x=0
    score=0
    for i in indexes:
        user_answers[x] == answer[i]
        score=score+1
        x +=1
    print(score)
    showresult(score)
        

ques = 1
def selected():
    global radiovar,user_answers
    global lblQuestion,r1,r2,r3,r4
    global ques
    x = radiovar.get()
    user_answers.append(x)
    radiovar.set(-1)
    if ques < 10:
        lblQuestion.config(text= questions[indexes[ques]])
        r1['text'] = answers_choice[indexes[ques]][0]
        r2['text'] = answers_choice[indexes[ques]][1]
        r3['text'] = answers_choice[indexes[ques]][2]
        r4['text'] = answers_choice[indexes[ques]][3]
        ques += 1

    else:
        #print(indexes)
        #print(user_answers)
        calc()

def startquiz():
    global lblQuestion,r1,r2,r3,r4
    lblQuestion=Label(
        root,
        text= questions[indexes[0]],
        font = ("Consolus", 18),
        width = 500,
        justify = "center",
        wraplength = 500,
        background ="#FFFFB9",
    )
    lblQuestion.pack(pady=(100,30))
    
    global radiovar
    radiovar = IntVar()
    radiovar.set(-1)
    
    r1 = Radiobutton(
        root,
        text = answers_choice[indexes[0]][0],
        font = ("Consolus", 14),
        value = 0,
        variable = radiovar,
        command = selected,
        background ="#CDCD10",
    )
    r1.pack(pady=5)

    r2 = Radiobutton(
        root,
        text = answers_choice[indexes[0]][1],
        font = ("Consolus", 14),
        value = 1,
        variable = radiovar,
        command = selected,
        background ="#CDCD10",
    )
    r2.pack(pady=5)

    r3 = Radiobutton(
        root,
        text = answers_choice[indexes[0]][2],
        font = ("Consolus", 14),
        value = 2,
        variable = radiovar,
        command = selected,
        background ="#CDCD10",
    )
    r3.pack(pady=5)

    r4 = Radiobutton(
        root,
        text = answers_choice[indexes[0]][3],
        font = ("Consolus", 14),
        value = 3,
        variable = radiovar,
        command = selected,
        background ="#CDCD10",
    )
    r4.pack(pady=5)
    
def startIspressed():
    labelimage.destroy()
    labeltext.destroy()
    labelinstrucion.destroy()
    labelrule.destroy()
    btnstart.destroy()
    gen()
    startquiz()
    

root = tkinter.Tk()
root.title("THE INVINCIBLE")
root.geometry("700x900")
root.configure(background="#ffffff")
root.resizable(0,0)

img1 = PhotoImage(file="top.jpg")

labelimage = Label(
    root,
    image = img1,
    background = "#ffffff"
)
labelimage.pack(padx=80)


labeltext = Label(
    root,
    text = "THE INVINCIBLE",
    font = ("comic sans MS",20,"bold"),
    background = "#ffffff"
)
labeltext.pack()

img2 = PhotoImage(file="e:\university\1st SEM\PFUND PROJECT\start.PNG")

btnstart = Button(
    root,
    image = img2,
    relief = FLAT,
    border =  0,
    command = startIspressed,
)
btnstart.pack()

labelinstrucion = Label(
    root,
    text = "Read The Rules And \n Click Start Once You Are Ready",
    background = "#ffffff",
    font = ("consolas",12),
    justify = "center"
)
labelinstrucion.pack(pady=30)

labelrule = Label(
    root,
    text = "RULES:  \n This quiz contains 10 questions\nYou will get 20 seconds to solve a question\nOnce you select a radio button that will be a final choice\nhence think before you select",
    width = 100,
    font = ("Times",14),
    background = "#000000",
    foreground = "#FACA2F",
)
labelrule.pack(pady=20)



root.mainloop()